# 🔍 Code Review Report

## Summary

| Metric | Value |
|--------|-------|
| **Overall Score** | 45/100 |
| **Files Reviewed** | 2 |
| **Critical Issues** | 11 |
| **High Priority Tests** | 7 |
| **Refactoring Opportunities** | 11 |

## 🎯 Top Recommendations

1. 🚨 **Security**: SQL Injection: All 5 database functions (getSubscription, searchSubscriptions, createSubscription, cancelSubscription, canAddTodo) use string concatenation instead of parameterized queries. This allows attackers to execute arbitrary SQL commands, potentially accessing or deleting all data.
   - Files: src/subscription.js

2. 🚨 **Security**: Code Injection via eval(): The chargeCard function uses eval() on user input (amountStr), allowing arbitrary JavaScript code execution. An attacker could execute system commands, read files, or compromise the entire application.
   - Files: src/subscription.js

3. 🚨 **Security**: Hardcoded Secrets: Production API keys (PAYMENT_API_SECRET, ADMIN_OVERRIDE_TOKEN) are hardcoded in source code and committed to the repository. Anyone with repo access has full payment API access and can bypass admin authentication.
   - Files: src/subscription.js

4. 🚨 **Security**: Authentication Bypass: The isAdmin function accepts a client-controlled isAdmin flag from request.body, allowing any user to grant themselves admin privileges by simply setting isAdmin: true in their request.
   - Files: src/subscription.js

5. 🚨 **Security**: PCI DSS Violation: The createSubscription function logs full credit card numbers, CVV codes, and plaintext passwords to console. This violates payment card industry standards and exposes highly sensitive customer data.
   - Files: src/subscription.js

## 📁 File Details

### 📄 `src/db.js`

**Quality Score:** 75/100 | **Coverage:** ~0%

#### Issues (1)
  - Line 6: `medium` The query method has no error handling mechanism. Real database operations can fail, and this shim provides no way to simulate or handle errors.


#### Test Gaps (1)
  - `createConnection (lines 3-9)` (low priority)


#### Refactoring Opportunities (1)
  - **modernize**: Add JSDoc documentation to clarify this is a fixture/mock implementation


---

### 📄 `src/subscription.js`

**Quality Score:** 15/100 | **Coverage:** ~0%

#### Issues (18)
  - Line 6: `critical` PAYMENT_API_SECRET contains what appears to be a production API key hardcoded in source code. This is a severe security vulnerability that exposes payment system credentials.
  - Line 7: `critical` ADMIN_OVERRIDE_TOKEN is hardcoded, allowing anyone with access to the source code to gain admin privileges. This bypasses all authentication mechanisms.
  - Line 19: `critical` Direct string concatenation in SQL query allows SQL injection attacks. User-controlled userId is concatenated directly into the query.

  *...and 15 more*

#### Test Gaps (10)
  - `getSubscription (line 16)` (critical priority)
  - `searchSubscriptions (line 25)` (critical priority)

  *...and 8 more*

#### Refactoring Opportunities (10)
  - **pattern-improvement**: CRITICAL: SQL Injection vulnerability - use parameterized queries instead of string concatenation
  - **pattern-improvement**: CRITICAL: Multiple SQL injection vulnerabilities in dynamic query building

  *...and 8 more*

---

*Generated at 2026-09-29T00:00:00Z • Duration: 0ms*
